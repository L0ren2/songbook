# songbook

This is the songbook template used by my local scout group. You are free to use and modify it.
Because this songbook is using the [LaTeX Songs Package](http://songs.sourceforge.net/), it is licensed under the GPL v2.0. 
The original songs package itself has not been modified for this purpose. 
If you are using this as your template please be sure to share your sources as well. 
Happy singing :)

### general build instructions

On Linux (Mac should work the same) just run `make` inside the build directory. 

On Windows just run `make.bat` inside the build directory. 

